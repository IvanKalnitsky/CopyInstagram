

import UIKit
import SnapKit
import AVFoundation

protocol ViewProtocol: class {
}

class ModuleViewController: UIViewController, ViewProtocol {

    let presenter: PresenterProtocol
    init(presenter: PresenterProtocol) {
        self.presenter = presenter
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("don't use storyboards!")
    }

    //MARK: Methods

    override func viewDidLoad() {
        super.viewDidLoad()
        initialize()
    }

    private func initialize() {
    }

}
