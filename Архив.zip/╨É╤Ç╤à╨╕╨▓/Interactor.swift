

import UIKit

protocol InteractorProtocol: class {
}

class Interactor: InteractorProtocol {

    weak var presenter: PresenterProtocol?

}
