

protocol PresenterProtocol: class {
    var interactor: InteractorProtocol { get }
}

class Presenter: PresenterProtocol {

    weak var view: ViewProtocol?
    let interactor: InteractorProtocol

    init(interactor: InteractorProtocol) {
        self.interactor = interactor
    }

}
