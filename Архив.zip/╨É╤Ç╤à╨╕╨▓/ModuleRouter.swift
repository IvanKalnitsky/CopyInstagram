

import Foundation

protocol ModuleRouterProtocol: BaseRouterProtocol {
}

class ModuleRouter: BaseRouter<ModuleViewController>, ModuleRouterProtocol {
}
